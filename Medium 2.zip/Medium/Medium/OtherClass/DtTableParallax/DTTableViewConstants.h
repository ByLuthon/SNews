//
//  DTTableViewConstants.h
//
//  Created by ToanDK on 4/28/15.
//  Copyright (c) 2015 ToanDK. All rights reserved.
//

#ifndef lec1_DTTableViewConstants_h
#define lec1_DTTableViewConstants_h

#define kDTImageViewOffsetY 75

#define kDTScaleLimitOffset 50

#endif
