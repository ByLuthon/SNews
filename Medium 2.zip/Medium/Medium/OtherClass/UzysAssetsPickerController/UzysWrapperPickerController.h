//
//  UzysWrapperPickerController.h
//  IdolChat
//
//  Created by Uzysjung on 2014. 1. 28..
//  Copyright (c) 2014년 SKPlanet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UzysWrapperPickerController : UIImagePickerController
@end
