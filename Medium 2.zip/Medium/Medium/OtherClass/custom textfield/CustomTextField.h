//
//  CustomTextField.h
//  Fitness
//
//  Created by rlogical-dev-21 on 09/01/17.
//  Copyright © 2017 rlogical-dev-21. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTextField : UITextField

@property (nonatomic) IBInspectable CGFloat padding;

@end

