//
//  Cell_FollowFollowing.m
//  SNews
//
//  Created by macmini on 16/02/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import "Cell_FollowFollowing.h"

@implementation Cell_FollowFollowing

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
