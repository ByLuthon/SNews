//
//  Cell_user.m
//  LinkedinClone
//
//  Created by macmini on 01/03/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import "Cell_user.h"

@implementation Cell_user

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
