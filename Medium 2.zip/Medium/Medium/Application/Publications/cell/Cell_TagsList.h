//
//  Cell_TagsList.h
//  SNews
//
//  Created by macmini on 21/02/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Cell_TagsList : UITableViewCell
{
    
}
@property (weak, nonatomic) IBOutlet UIImageView *cell_imgtags;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UIButton *btn_select;

@end
