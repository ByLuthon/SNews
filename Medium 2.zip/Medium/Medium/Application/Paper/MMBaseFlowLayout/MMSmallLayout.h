//
//  MMSmallLayout.h
//  MMPaper
//
//  Created by mukesh mandora on 26/12/14.
//  Copyright (c) 2014 com.muku. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMSmallLayout : UICollectionViewFlowLayout

@end
