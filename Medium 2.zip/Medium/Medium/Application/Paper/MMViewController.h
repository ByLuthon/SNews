//
//  MMViewController.h
//  MMPaper
//
//  Created by muku on 12/10/14.
//  Copyright (c) 2014 com.muku. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMBaseCollection.h"
@interface MMViewController : MMBaseCollection
//@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
