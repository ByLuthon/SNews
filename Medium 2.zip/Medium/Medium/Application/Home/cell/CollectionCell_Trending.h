//
//  CollectionCell_Trending.h
//  SNews
//
//  Created by macmini on 03/02/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

@interface CollectionCell_Trending : UICollectionViewCell
{
    
}
@property (weak, nonatomic) IBOutlet UIView *subview;
@property (weak, nonatomic) IBOutlet UIImageView *img_list;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;

@end
