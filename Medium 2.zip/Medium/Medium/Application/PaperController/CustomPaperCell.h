//
//  CustomPaperCell.h
//  Medium
//
//  Created by macmini on 10/03/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomPaperCell : UICollectionViewCell

@end
