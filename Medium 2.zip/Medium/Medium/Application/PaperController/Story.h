//
//  Story.h
//  Medium
//
//  Created by macmini on 10/03/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

//@import QuartzCore;

@interface Story : UIView

@end
