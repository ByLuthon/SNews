//
//  ActivityViewController.h
//  SNews
//
//  Created by macmini on 06/02/17.
//  Copyright © 2017 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cell_Activity.h"
#import "Common.h"

@interface ActivityViewController : UIViewController
{
    __weak IBOutlet UITableView *tbl;
}

@end
